package CRUD;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class FrameMataKuliah extends JFrame {
    private JTextField idMKField, namaMKField;
    private JTable table;
    private DefaultTableModel tableModel;
    private CrudDatabaseService crudService;

    public FrameMataKuliah() {
        crudService = new CrudDatabaseService();

        setTitle("Mata Kuliah CRUD Application");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel inputPanel = new JPanel(new GridLayout(3, 2));
        inputPanel.add(new JLabel("ID Mata Kuliah:"));
        idMKField = new JTextField();
        inputPanel.add(idMKField);

        inputPanel.add(new JLabel("Nama Mata Kuliah:"));
        namaMKField = new JTextField();
        inputPanel.add(namaMKField);

        JButton createButton = new JButton("Create");
        createButton.addActionListener(this::handleCreate);
        inputPanel.add(createButton);

        JButton updateButton = new JButton("Update");
        updateButton.addActionListener(this::handleUpdate);
        inputPanel.add(updateButton);

        JButton deleteButton = new JButton("Delete");
        deleteButton.addActionListener(this::handleDelete);
        inputPanel.add(deleteButton);

        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(e -> refreshTable());
        inputPanel.add(refreshButton);

        add(inputPanel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new String[]{"ID Mata Kuliah", "Nama Mata Kuliah"}, 0);
        table = new JTable(tableModel);
        add(new JScrollPane(table), BorderLayout.CENTER);

        refreshTable();
    }

    private void handleCreate(ActionEvent e) {
        int idMK = Integer.parseInt(idMKField.getText());
        String namaMK = namaMKField.getText();
        crudService.createMataKuliah(idMK, namaMK);
        refreshTable();
        clearFields();
    }

    private void handleUpdate(ActionEvent e) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            int idMK = Integer.parseInt(idMKField.getText());
            String namaMK = namaMKField.getText();
            crudService.updateMataKuliah(idMK, namaMK);
            refreshTable();
            clearFields();
        } else {
            JOptionPane.showMessageDialog(this, "Select a row to update.");
        }
    }

    private void handleDelete(ActionEvent e) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            int idMK = (int) tableModel.getValueAt(selectedRow, 0);
            crudService.deleteMataKuliah(idMK);
            refreshTable();
        } else {
            JOptionPane.showMessageDialog(this, "Select a row to delete.");
        }
    }

    private void refreshTable() {
        List<MataKuliah> mataKuliahList = crudService.readMataKuliah();
        tableModel.setRowCount(0);
        for (MataKuliah mataKuliah : mataKuliahList) {
            tableModel.addRow(new Object[]{mataKuliah.getId_mk(), mataKuliah.getNama_mk()});
        }
    }

    private void clearFields() {
        idMKField.setText("");
        namaMKField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FrameMataKuliah().setVisible(true));
    }
}