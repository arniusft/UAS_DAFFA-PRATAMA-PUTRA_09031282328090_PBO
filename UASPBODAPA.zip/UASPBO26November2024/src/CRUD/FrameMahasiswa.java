package CRUD;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class FrameMahasiswa extends JFrame {
    private JTextField nimField, id_mahasiswaField, namaField;
    private JTable table;
    private DefaultTableModel tableModel;
    private CrudDatabaseService crudService;

    public FrameMahasiswa() {
    crudService = new CrudDatabaseService();

    setTitle("Mahasiswa CRUD Application");
    setSize(600, 400);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLocationRelativeTo(null);

    JPanel inputPanel = new JPanel(new GridLayout(4, 2));
    inputPanel.add(new JLabel("NIM:"));
    nimField = new JTextField();
    inputPanel.add(nimField);

    inputPanel.add(new JLabel("ID Mahasiswa:"));
    id_mahasiswaField = new JTextField();
    inputPanel.add(id_mahasiswaField);

    inputPanel.add(new JLabel("Nama"));
    namaField = new JTextField();
    inputPanel.add(namaField);

    JButton createButton = new JButton("Create");
    createButton.addActionListener(this::handleCreate);
    inputPanel.add(createButton);

    JButton updateButton = new JButton("Update");
    updateButton.addActionListener(this::handleUpdate);
    inputPanel.add(updateButton);

    JButton deleteButton = new JButton("Delete");
    deleteButton.addActionListener(this::handleDelete);
    inputPanel.add(deleteButton);

    JButton refreshButton = new JButton("Refresh");
    refreshButton.addActionListener(e -> refreshTable());
    inputPanel.add(refreshButton);

    add(inputPanel, BorderLayout.NORTH);

    tableModel = new DefaultTableModel(new String[]{"NIM", "ID Mahasiswa", "Nama"}, 0);
    table = new JTable(tableModel);
    add(new JScrollPane(table), BorderLayout.CENTER);

    refreshTable();
}

private void handleCreate(ActionEvent e) {
    int nim = Integer.parseInt(nimField.getText());
    String id_mahasiswa = id_mahasiswaField.getText();
    int nama = Integer.parseInt(namaField.getText());
    crudService.createMahasiswa(nim, id_mahasiswa, nama);
    refreshTable();
    clearFields();
}

private void handleUpdate(ActionEvent e) {
    int selectedRow = table.getSelectedRow();
    if (selectedRow >= 0) {
        int nim = Integer.parseInt(nimField.getText());
        String id_mahasiswa = id_mahasiswaField.getText();
        String nama = namaField.getText();
        crudService.updateMahasiswa(nim, id_mahasiswa, nama);
        refreshTable();
        clearFields();
    } else {
        JOptionPane.showMessageDialog(this, "Select a row to update.");
    }
}

private void handleDelete(ActionEvent e) {
    int selectedRow = table.getSelectedRow();
    if (selectedRow >= 0) {
        int nim = (int) tableModel.getValueAt(selectedRow, 0);
        crudService.deleteMahasiswa(nim);
        refreshTable();
    } else {
        JOptionPane.showMessageDialog(this, "Select a row to delete.");
    }
}

private void refreshTable() {
    List<Mahasiswa> mahasiswa = crudService.readMahasiswa();
    tableModel.setRowCount(0);
    for (Mahasiswa Mahasiswa : mahasiswa) {
        tableModel.addRow(new Object[]{Mahasiswa.getNim(), Mahasiswa.getId_mahasiswa(), Mahasiswa.getNama()});
    }
}

private void clearFields() {
    nimField.setText("");
    id_mahasiswaField.setText("");
    namaField.setText("");
}

public static void main(String[] args) {
    SwingUtilities.invokeLater(() -> new FrameMahasiswa().setVisible(true));
}
}