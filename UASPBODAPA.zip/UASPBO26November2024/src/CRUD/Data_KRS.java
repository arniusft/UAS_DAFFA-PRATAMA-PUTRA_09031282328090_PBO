package CRUD;

public class Data_KRS {
    private int id_krs;
    private int id_mahasiswa;
    private int id_mk;
    private int semester;
    private int tahun_ajaran;
    
    Data_KRS(int id_krs, int id_mahasiswa, int id_mk, int semester, int tahun_ajaran){
        this.id_krs = id_krs;
        this.id_mk = id_mk;
        this.id_mahasiswa = id_mahasiswa;
        this.semester = semester;
        this.tahun_ajaran = tahun_ajaran;
       
    }
    
    public int getId_krs(){
        return id_krs;
    }
    public int getId_mk(){
        return id_mahasiswa;
    }
    public int getId_mahasiswa(){
        return id_mk;
    }
    public int getSemester(){
        return semester;
    }
    public int getTahun_Ajaran(){
        return tahun_ajaran;
    }
}
