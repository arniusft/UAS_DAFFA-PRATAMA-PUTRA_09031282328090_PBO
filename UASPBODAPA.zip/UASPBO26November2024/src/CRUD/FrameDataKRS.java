package CRUD;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class FrameDataKRS extends JFrame {
    private JTextField idKRSField, idMahasiswaField, idMKField, semesterField, tahunAjaranField;
    private JTable table;
    private DefaultTableModel tableModel;
    private CrudDatabaseService crudService;

    public FrameDataKRS() {
        crudService = new CrudDatabaseService();

        setTitle("Data KRS CRUD Application");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel inputPanel = new JPanel(new GridLayout(6, 2));
        inputPanel.add(new JLabel("ID KRS:"));
        idKRSField = new JTextField();
        inputPanel.add(idKRSField);

        inputPanel.add(new JLabel("ID Mahasiswa:"));
        idMahasiswaField = new JTextField();
        inputPanel.add(idMahasiswaField);

        inputPanel.add(new JLabel("ID Mata Kuliah:"));
        idMKField = new JTextField();
        inputPanel.add(idMKField);

        inputPanel.add(new JLabel("Semester:"));
        semesterField = new JTextField();
        inputPanel.add(semesterField);

        inputPanel.add(new JLabel("Tahun Ajaran:"));
        tahunAjaranField = new JTextField();
        inputPanel.add(tahunAjaranField);

        JButton createButton = new JButton("Create");
        createButton.addActionListener(this::handleCreate);
        inputPanel.add(createButton);

        JButton updateButton = new JButton("Update");
                updateButton.addActionListener(this::handleUpdate);
        inputPanel.add(updateButton);

        JButton deleteButton = new JButton("Delete");
        deleteButton.addActionListener(this::handleDelete);
        inputPanel.add(deleteButton);

        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(e -> refreshTable());
        inputPanel.add(refreshButton);

        add(inputPanel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new String[]{"ID KRS", "ID Mahasiswa", "ID Mata Kuliah", "Semester", "Tahun Ajaran"}, 0);
        table = new JTable(tableModel);
        add(new JScrollPane(table), BorderLayout.CENTER);

        refreshTable();
    }

    private void handleCreate(ActionEvent e) {
        try {
            int idkrs = Integer.parseInt(idKRSField.getText());
            int idMahasiswa = Integer.parseInt(idMahasiswaField.getText());
            int idMK = Integer.parseInt(idMKField.getText());
            int semester = Integer.parseInt(semesterField.getText());
            int tahunAjaran = Integer.parseInt(tahunAjaranField.getText());
            crudService.createData_KRS(idkrs,idMahasiswa, idMK, semester, tahunAjaran);
            refreshTable();
            clearFields();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleUpdate(ActionEvent e) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            try {
                int idKRS = (int) tableModel.getValueAt(selectedRow, 0);
                int idMahasiswa = Integer.parseInt(idMahasiswaField.getText());
                int idMK = Integer.parseInt(idMKField.getText());
                int semester = Integer.parseInt(semesterField.getText());
                int tahunAjaran = Integer.parseInt(tahunAjaranField.getText());
                crudService.updateDataKRS(idKRS, idMahasiswa, idMK, semester, tahunAjaran);
                refreshTable();
                clearFields();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter valid numbers.", "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Select a row to update.");
        }
    }

    private void handleDelete(ActionEvent e) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            int idKRS = (int) tableModel.getValueAt(selectedRow, 0);
            crudService.deleteDataKRS(idKRS);
            refreshTable();
        } else {
            JOptionPane.showMessageDialog(this, "Select a row to delete.");
        }
    }

    private void refreshTable() {
        List<Data_KRS> dataKRSList = crudService.readTransaksi();
        tableModel.setRowCount(0); // Clear existing rows
        for (Data_KRS dataKRS : dataKRSList) {
            tableModel.addRow(new Object[]{dataKRS.getId_krs(), dataKRS.getId_mahasiswa(), dataKRS.getId_mk(), dataKRS.getSemester(), dataKRS.getTahun_Ajaran()});
        }
    }

    private void clearFields() {
        idKRSField.setText("");
        idMahasiswaField.setText("");
        idMKField.setText("");
        semesterField.setText("");
        tahunAjaranField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FrameDataKRS().setVisible(true));
    }
}