package CRUD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CrudDatabaseService {
    // CRUD Barang
    public void createMahasiswa(int nim, String id_mahasiswa, int nama) {
        String query = "INSERT INTO barang (nim, id_mahasiswa, nama) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, nim);
            stmt.setString(2, id_mahasiswa);
            stmt.setInt(3, nama);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Mahasiswa> readMahasiswa() {
    List<Mahasiswa> mahasiswaList = new ArrayList<>();
    String query = "SELECT * FROM mahasiswa";
    try (Connection conn = DatabaseConnection.connect();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(query)) {
        while (rs.next()) {
            mahasiswaList.add(new Mahasiswa(
                    rs.getInt("nim"),
                    rs.getString("id_mahasiswa"),
                    rs.getString("nama")));
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return mahasiswaList;
}

public void updateMahasiswa(int nim, String id_mahasiswa, String nama) {
    String query = "UPDATE barang SET id_mahasiswa = ?, nama = ? WHERE nim = ?";
    try (Connection conn = DatabaseConnection.connect();
         PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.setInt(1, nim);
        stmt.setString(2, id_mahasiswa);
        stmt.setString(3, nama);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

public void deleteMahasiswa(int nim) {
    String query = "DELETE FROM mahasiswa WHERE nim = ?";
    try (Connection conn = DatabaseConnection.connect();
         PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.setInt(1, nim);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

// CRUD Konsumen
public void createMataKuliah(int id_mk, String nama_mk) {
    String query = "INSERT INTO konsumen (id_mk, nama_mk) VALUES (?, ?)";
    try (Connection conn = DatabaseConnection.connect();
         PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.setInt(1, id_mk);
        stmt.setString(2, nama_mk);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

public List<MataKuliah> readMataKuliah() {
    List<MataKuliah> konsumenList = new ArrayList<>();
    String query = "SELECT * FROM MataKuliah";
    try (Connection conn = DatabaseConnection.connect();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(query)) {
        while (rs.next()) {
            konsumenList.add(new MataKuliah(
                    rs.getInt("id_mk"),
                    rs.getString("nama_mk")));
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return konsumenList;
}

public void updateMataKuliah(int id_mk, String nama_mk) {
    String query = "UPDATE konsumen SET nama_mk = ? WHERE id_mk = ?";
    try (Connection conn = DatabaseConnection.connect();
         PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.setInt(1, id_mk);
        stmt.setString(2, nama_mk);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

public void deleteMataKuliah(int id_mk) {
    String query = "DELETE FROM MataKuliah WHERE id_mk = ?";
    try (Connection conn = DatabaseConnection.connect();
         PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.setInt(1, id_mk);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

// CRUD Transaksi
public void createData_KRS(int id_krs, int id_mahasiswa, int id_mk, int semester, int tahun_ajaran) {
    String query = "INSERT INTO Data_KRS (id_krs, id_mahasiswa, id_mk, semester, tahun_ajaran) VALUES (?, ?, ?, ?, ?)";
    try (Connection conn = DatabaseConnection.connect();
         PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.setInt(1, id_krs);
        stmt.setInt(2, id_mahasiswa);
        stmt.setInt(3, id_mk);
        stmt.setInt(4, semester);
        stmt.setInt(5, tahun_ajaran);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

public List<Data_KRS> readTransaksi() {
    List<Data_KRS> transaksiList = new ArrayList<>();
    String query = "SELECT * FROM Data_KRS";
    try (Connection conn = DatabaseConnection.connect();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(query)) {
        while (rs.next()) {
            transaksiList.add(new Data_KRS(
                    rs.getInt("id_krs"),
                    rs.getInt("id_mk"),
                    rs.getInt("id_mahasiswa"),
                    rs.getInt("semester"),
                    rs.getInt("tahun_ajaran")));
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return transaksiList;
}

public void updateDataKRS(int id_krs, int id_mahasiswa, int id_mk, int semester, int tahun_ajaran) {
    String query = "UPDATE Data_KRS SET id_mahasiswa = ?, id_mk = ?, semeseter = ?, tahun_ajaran = ? WHERE id_krs = ?";
    try (Connection conn = DatabaseConnection.connect();
         PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.setInt(1, id_mahasiswa);
        stmt.setInt(2, id_mk);
        stmt.setInt(3, semester);
        stmt.setInt(4, tahun_ajaran);
        stmt.setInt(5, id_krs);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

public void deleteDataKRS(int id_krs) {
    String query = "DELETE FROM Data_KRS WHERE id_krs = ?";
    try (Connection conn = DatabaseConnection.connect();
         PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.setInt(1, id_krs);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
}
