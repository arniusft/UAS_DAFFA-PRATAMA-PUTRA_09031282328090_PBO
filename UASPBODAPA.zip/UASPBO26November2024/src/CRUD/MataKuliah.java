package CRUD;

public class MataKuliah {
    private int id_mk;
    private String nama_mk;
    
    MataKuliah(int id_mk, String nama_mk){
        this.id_mk = id_mk;
        this.nama_mk = nama_mk;
    }
    
    public int getId_mk(){
        return id_mk;
    }
    
    public String getNama_mk(){
        return nama_mk;
    }
}
