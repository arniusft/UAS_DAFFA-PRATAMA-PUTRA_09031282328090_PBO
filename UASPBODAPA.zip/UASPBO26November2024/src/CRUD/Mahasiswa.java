package CRUD;

public class Mahasiswa {
    private int nim;
    private String id_mahasiswa;
    private String nama;
    
    Mahasiswa (int nim,String id_mahasiswa, String nama){
        this.nim = nim;
        this.id_mahasiswa = id_mahasiswa;
        this.nama = nama;
    }
    public int getNim(){
        return nim;
    }
    
    public String getId_mahasiswa(){
        return id_mahasiswa;
    }
    
    public String getNama(){
        return nama;
    }
}
